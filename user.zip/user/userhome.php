<?php
require '../config/connect.php';
$user_id = $_SESSION['id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SUNRISE - HOME (DASHBOARD)</title>

        <!-- Font Awesome Icons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
        
        <!-- Stylesheet -->
        <link rel="stylesheet" href="../user/userstyle.css" />
        <style>
            
        </style>
    </head>
    <body>
        <!-- header -->
        <?php include '../user/userheader.php'; ?>
        <!-- dashboard -->
        <section class="dashboard">

            <h1 class="heading"><i class="fa fa-tachometer" aria-hidden="true"></i> dashboard</h1>
         
            <div class="box-container">
         
               <div class="box">
                  <h3>Welcome!</h3>
                  <p><?php echo $row["name"]; ?></p>
                  <a href="../user/usereditprofile.php" class="btn">Edit Profile</a>
               </div>
         
               
         
               
         
            </div>
         
         </section>
         <section class="graph">
            
         </section>
         
        
        <script type="text/javascript" src="../user/user.js"></script>
        <script>
           
        </script>
    </body>
</html>