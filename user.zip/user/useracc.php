<?php

include '../config/connect.php';

$user_id = $_SESSION['id'];

if(!isset($user_id)){
   header('location:userlogin.php');
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>SUNRISE </title>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <link rel="stylesheet" href="../user/userstyle.css">

</head>
<body>

<?php include '../user/userheader.php'; ?>

<section class="accounts">

   <h1 class="heading"><i class="fa fa-user-secret" aria-hidden="true"></i>User Profile</h1>

   <div class="box-container">
   
   <?php
      $select = mysqli_query($conn, "SELECT * FROM admins where id='$user_id'");
         while($row = mysqli_fetch_assoc($select)){ 
   ?>
   <div class="box">
      <p> ID : <span><?php echo $row['id']; ?></span> </p>
      <p> Name : <span><?php echo $row['name']; ?></span> </p>
      <p> Username : <span><?php echo $row['username']; ?></span> </p>
      <p> Email : <span><?php echo $row['email']; ?></span> </p>
      <p> Contact No. : <span><?php echo $row['phone']; ?></span> </p>
      <div class="flex-btn"> 
         <?php
            if($row['id'] == $user_id){
               echo '<a href="../user/usereditprofile.php" class="option-btn">Edit</a>';
            }
         ?>
      </div>
   </div>
   <?php
         }
   ?>

   </div>

</section>












<script src="../admin/admin.js"></script>
   
</body>
</html>