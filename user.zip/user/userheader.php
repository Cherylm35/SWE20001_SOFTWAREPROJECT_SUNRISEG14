<header class="header">

<section class="flex">

    <a href="../user/userhome.php" class="logo">SUN<span>RISE</span></a>

    <nav class="navbar">
        <a href="../user/userhome.php">Home</a>
        <a href="../user/userproducts.php">Products</a>
        <a href="../user/userrentals.php">Rentals History</a>
        <a href="">Payment</a>

    </nav>

    <div class="icons">
        <div id="menu-btn" class="fas fa-bars"></div>
        <div id="user-btn" class="fas fa-user-cog"></div>
    </div>

    <div class="profile">
        <?php
            $id = $_SESSION["id"];
            $result = mysqli_query($conn, "SELECT * FROM admins WHERE id = $id");
            $row = mysqli_fetch_assoc($result);
         ?>
         <p><span>Hi, <?php echo $row['name']; ?></span></p>
        <p></p>
        <a href="../user/usereditprofile.php" class="btn">Edit Profile</a>
        <div class="flex-btn">
            <a href="../user/useracc.php" class="option-btn">Account</a>
        </div>
        <a href="../user/userlogout.php" class="delete-btn" onclick="return confirm('Are you sure you want to log out?');">Logout</a> 
    </div>

</section>

</header>